package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.model.Buyer;
import com.ecommerce.repository.BuyerRepository;

@Service
public class BuyerService {
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	
	public List<Buyer> getAllBuyer() {
		return buyerRepository.findAll();
	}
	
	public Integer createBuyer(Buyer buyer) {
		Buyer newBuyer = (Buyer)buyerRepository.save(buyer);
		return newBuyer.getBuyerId();
	}
	
	public Buyer updateBuyer(Buyer buyer) {
		Optional<Buyer> existingBuyer = buyerRepository.findById(buyer.getBuyerId());
		Buyer newBuyer = null;
		if(existingBuyer.isPresent()) {
			newBuyer = existingBuyer.get();
			newBuyer.setUsername(buyer.getUsername());
			newBuyer.setPassword(buyer.getPassword());
			newBuyer.setEmailId(buyer.getEmailId());
			newBuyer.setMobileNumber(buyer.getMobileNumber());
			newBuyer = buyerRepository.save(newBuyer);
		}
		
		return newBuyer;
	}
	
	public Optional<Buyer> getBuyerById(Integer buyerId) {
		return buyerRepository.findById(buyerId);
	}
	

}
