package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.model.Buyer;
import com.ecommerce.model.ShoppingCart;

@Service
public class ShoppingCartService {
	
	@Autowired
	private ShoppingCartService shoppingcartservice;
	
	
	

	
	

}
