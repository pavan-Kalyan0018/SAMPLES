package com.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.model.TransactionHistory;

public interface TransactionRepository extends JpaRepository<TransactionHistory, Long>{

}
